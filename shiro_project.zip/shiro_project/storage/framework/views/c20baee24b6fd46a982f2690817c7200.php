<?php
    foreach ($monitoring as $data) {
        echo $data->temperature;
    }
?><?php /**PATH C:\laragon\www\shiro_project\resources\views/bacasuhu.blade.php ENDPATH**/ ?>