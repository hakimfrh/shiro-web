<?php $__env->startSection('container'); ?>
    <div class="container-fluid pt-4 px-4">
        <div class="bg-light text-center rounded p-4">
            <?php if(session()->has('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <div class="d-flex align-items-center justify-content-between mb-4">
                <h6 class="mb-0">Riwayat Monitoring</h6>
            </div>
            <form action="/dashboard/controls" method="get">
                <div class="input-group mb-3">
                    <input type="date" class="form-control" name="filter" value="<?php echo e(request('filter') ?: $today); ?>">
                    <button class="btn btn-warning" type="submit"><i class="bx bx-search"></i> Filter</button>
                </div>
            </form>
            <a class="btn btn-secondary mb-3" target="_blank"
                href="/dashboard/cetak<?php echo e(request()->has('filter') ? '?filter=' . request('filter') : ''); ?>">
                <i class="bx bx-printer"></i> Cetak
            </a>
            <div class="table-responsive">
                <table class="table text-start align-middle table-bordered table-hover mb-0 text-center">
                    <thead>
                        <tr class="text-dark">
                            <th scope="col">No</th>
                            <th scope="col">Tanggal</th>
                            <th scope="col">Pukul</th>
                            <th scope="col">Suhu Air</th>
                            <th scope="col">TDS (PPM)</th>
                            <th scope="col">pH Air</th>
                            <th scope="col">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $controls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $control): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($control->created_at->format('d M Y')); ?></td>
                                <td><?php echo e($control->created_at->format('H:i')); ?></td>
                                <td><?php echo e($control->temperature); ?> °C</td>
                                <td><?php echo e($control->turbidity); ?> PPM</td>
                                <td><?php echo e($control->ph); ?></td>
                                <td>
                                    <form action="/dashboard/controls/<?php echo e($control->id); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button type="submit" class="btn btn-outline-danger">
                                            <i class="bx bx-trash me-1"></i> Hapus
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="text-center">Belum ada data</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\shiro_project\resources\views/dashboard/histories/index.blade.php ENDPATH**/ ?>