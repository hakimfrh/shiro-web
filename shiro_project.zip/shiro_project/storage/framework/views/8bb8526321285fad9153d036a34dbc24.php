
<script type="text/javascript" src="<?php echo e(asset('jquery/jquery.min.js')); ?>"></script>


<script type="text/javascript">
    $(document).ready(function() {
        let duration = 120000; // Durasi 2 menit dalam milidetik
        let interval = 1000; // Interval pembaruan 1 detik
        let elapsed = 0; // Waktu yang telah berjalan

        const intervalId = setInterval(function() {
            if (elapsed >= duration) {
                clearInterval(intervalId); // Hentikan pembaruan setelah 2 menit
            } else {
                $("#suhu").load("<?php echo e(url('bacasuhu')); ?>");
                $("#kekeruhan").load("<?php echo e(url('bacatds')); ?>"); // Ubah ke endpoint yang relevan
                $("#ph").load("<?php echo e(url('bacaph')); ?>");
                elapsed += interval;
            }
        }, interval);
    });
</script><?php /**PATH C:\laragon\www\shiro_project\resources\views/dashboard/realtime.blade.php ENDPATH**/ ?>