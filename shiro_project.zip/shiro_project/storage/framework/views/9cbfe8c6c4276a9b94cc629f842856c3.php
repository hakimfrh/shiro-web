<?php
    foreach ($monitoring as $data) {
        echo $data->turbidity;
    }
?><?php /**PATH C:\laragon\www\shiro_project\resources\views/bacatds.blade.php ENDPATH**/ ?>