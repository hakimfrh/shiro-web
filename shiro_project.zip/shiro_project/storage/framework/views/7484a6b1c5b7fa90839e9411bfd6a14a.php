<?php
    foreach ($monitoring as $data) {
        echo $data->ph;
    }
?><?php /**PATH C:\laragon\www\shiro_project\resources\views/bacaph.blade.php ENDPATH**/ ?>