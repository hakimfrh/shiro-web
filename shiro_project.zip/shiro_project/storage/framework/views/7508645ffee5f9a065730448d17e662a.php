<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rekap Monitoring | <?php echo e(request('filter') ?: now()->format('Y-m-d')); ?></title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="container pt-4">
        <h4 class="text-center">Rekap Data Monitoring</h4>
        <p class="text-center">Tanggal: <?php echo e(request('filter') ?: now()->format('d M Y')); ?></p>
        <table class="table table-bordered text-center">
            <thead>
                <tr>
                    <th>Pukul</th>
                    <th>Suhu Air (°C)</th>
                    <th>TDS (PPM)</th>
                    <th>pH Air</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $controls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $control): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($control->created_at->format('H:i')); ?></td>
                        <td><?php echo e($control->temperature); ?></td>
                        <td><?php echo e($control->turbidity); ?></td>
                        <td><?php echo e($control->ph); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4">Belum ada data</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <script>
        window.print();
    </script>
</body>

</html>
<?php /**PATH C:\laragon\www\shiro_project\resources\views/dashboard/histories/cetakhistory.blade.php ENDPATH**/ ?>