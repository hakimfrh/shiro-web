<?php
    foreach ($monitoring as $data) {
        echo $data->pompa_masuk;
    }
?>