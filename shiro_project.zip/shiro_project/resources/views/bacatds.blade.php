<?php
    foreach ($monitoring as $data) {
        echo $data->turbidity;
    }
?>