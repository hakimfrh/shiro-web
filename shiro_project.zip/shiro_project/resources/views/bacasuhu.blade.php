<?php
    foreach ($monitoring as $data) {
        echo $data->temperature;
    }
?>